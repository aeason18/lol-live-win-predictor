LoL live win predictor - model comparison (D3)

Contents
  notebooks/lol_15min_model_comparison.ipynb   the evaluation notebook (saved with outputs)
  data/training/lol_15min_live_train.csv       6,527 training matches
  data/training/lol_15min_live_test_HOLDOUT.csv  1,632 reserved test matches (scored once, in Section 10)
  data/training/lol_15min_test_HOLDOUT.sha256  fingerprint proving the test set is the one reserved up front
  data/training/lol_15min_live_data_dictionary.csv  what every column means
  win_model.json                               the deployed model (Section 9 compares against it)

To re-run (about 2 minutes, every random choice is seeded)
  1. py -m pip install numpy pandas scipy scikit-learn matplotlib jupyter
  2. Unzip, keeping this folder structure.
  3. Open notebooks/lol_15min_model_comparison.ipynb in Jupyter or VS Code and Run All.
     (Works if the notebook is started from this folder or from notebooks/.)
Tested with Python 3.14, numpy 2.4, pandas 3.0, scikit-learn 1.9, scipy 1.18, matplotlib 3.10.
